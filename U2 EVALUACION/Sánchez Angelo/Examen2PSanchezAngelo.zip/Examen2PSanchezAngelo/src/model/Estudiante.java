package model;

// Esta clase representa la entidad Estudiante con atributos básicos.
// Me gusta mantener los nombres claros y diferenciados para evitar confusiones.
public class Estudiante {
    private int idEstudiante;   // Prefiero usar idEstudiante para distinguirlo de otros IDs.
    private String apellido;    // Uso singular porque representa un valor.
    private String nombre;
    private int edad;

    // Constructor para inicializar todos los atributos al crear el objeto.
    public Estudiante(int idEstudiante, String apellido, String nombre, int edad) {
        this.idEstudiante = idEstudiante;
        this.apellido = apellido;
        this.nombre = nombre;
        this.edad = edad;
    }

    // Getters y setters convencionales para acceder y modificar datos.

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}
