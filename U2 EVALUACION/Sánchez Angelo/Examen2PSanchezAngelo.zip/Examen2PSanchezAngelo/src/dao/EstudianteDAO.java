package dao;

import model.Estudiante;
import java.util.ArrayList;
import java.util.List;

// DAO: Aquí manejo la "base de datos" en memoria.
// Prefiero usar métodos claros como guardar, obtenerTodos, eliminarPorId, etc.
public class EstudianteDAO {
    private List<Estudiante> listado = new ArrayList<>(); // Lista que simula almacenamiento

    // Guardar un nuevo estudiante, simplemente agrego a la lista.
    public void guardar(Estudiante estudiante) {
        listado.add(estudiante);
    }

    // Devuelve todos los estudiantes, útil para listados o reportes.
    public List<Estudiante> obtenerTodos() {
        return listado;
    }

    // Busca un estudiante por ID. Devuelvo null si no está, es simple y eficiente para pocos datos.
    public Estudiante obtenerPorId(int id) {
        for (Estudiante e : listado) {
            if (e.getIdEstudiante() == id) {
                return e;
            }
        }
        return null;
    }

    // Actualiza un estudiante buscando su posición y reemplazando el objeto.
    // Retorna true si encontró y actualizó, false si no.
    public boolean modificar(Estudiante estudianteActualizado) {
        for (int i = 0; i < listado.size(); i++) {
            if (listado.get(i).getIdEstudiante() == estudianteActualizado.getIdEstudiante()) {
                listado.set(i, estudianteActualizado);
                return true;
            }
        }
        return false;
    }

    // Elimina estudiante por ID usando removeIf que es más directo.
    // Retorna true si eliminó al menos uno.
    public boolean eliminarPorId(int id) {
        return listado.removeIf(e -> e.getIdEstudiante() == id);
    }
}
