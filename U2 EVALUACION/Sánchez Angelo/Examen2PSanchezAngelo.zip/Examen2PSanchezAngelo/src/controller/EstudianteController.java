package controller;

import dao.EstudianteDAO;
import model.Estudiante;
import java.util.List;

// Controlador coordina las operaciones entre vista y DAO.
// Prefiero mantenerlo simple, sólo pasa datos y llama métodos del DAO.
public class EstudianteController {
    private EstudianteDAO dao = new EstudianteDAO();

    // Crear un estudiante y guardarlo usando DAO
    public void crearEstudiante(int id, String apellido, String nombre, int edad) {
        Estudiante e = new Estudiante(id, apellido, nombre, edad);
        dao.guardar(e);
    }

    // Obtiene todos los estudiantes de DAO
    public List<Estudiante> obtenerTodos() {
        return dao.obtenerTodos();
    }

    // Busca un estudiante por ID usando DAO
    public Estudiante buscarEstudiante(int id) {
        return dao.obtenerPorId(id);
    }

    // Actualiza datos de un estudiante existente
    public boolean actualizarEstudiante(int id, String apellido, String nombre, int edad) {
        Estudiante actualizado = new Estudiante(id, apellido, nombre, edad);
        return dao.modificar(actualizado);
    }

    // Elimina estudiante por ID
    public boolean eliminarEstudiante(int id) {
        return dao.eliminarPorId(id);
    }

    // Verifica si un ID ya está en uso (para evitar duplicados)
    public boolean idExiste(int id) {
        return dao.obtenerPorId(id) != null;
    }
}
