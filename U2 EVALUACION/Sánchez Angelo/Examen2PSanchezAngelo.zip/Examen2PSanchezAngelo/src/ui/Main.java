package ui;

import controller.EstudianteController;
import model.Estudiante;
import java.util.Scanner;

// Aquí la interfaz de consola, simple y directa.
// Prefiero métodos pequeños para cada funcionalidad y evitar código repetido.
public class Main {
    private static EstudianteController controller = new EstudianteController();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        inicializarDatosEjemplo();

        while (true) {
            limpiarPantalla();
            mostrarMenu();
            int opcion = leerEntero();

            switch (opcion) {
                case 1 -> crearEstudiante();
                case 2 -> listarEstudiantes();
                case 3 -> buscarEstudiantePorId();
                case 4 -> actualizarEstudiante();
                case 5 -> eliminarEstudiante();
                case 6 -> {
                    System.out.println("Saliendo...");
                    scanner.close();
                    System.exit(0);
                }
                default -> {
                    System.out.println("Opción inválida. Intenta de nuevo.");
                    esperarEnter();
                }
            }
        }
    }

    private static void inicializarDatosEjemplo() {
        controller.crearEstudiante(1, "Pérez", "Ana", 20);
        controller.crearEstudiante(2, "García", "Luis", 22);
    }

    private static void limpiarPantalla() {
        // Este es un truco para limpiar consola, funciona en muchas pero no en todas.
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    private static void mostrarMenu() {
        System.out.println("=== CRUD Estudiantes ===");
        System.out.println("1. Crear estudiante");
        System.out.println("2. Listar estudiantes");
        System.out.println("3. Buscar estudiante por ID");
        System.out.println("4. Actualizar estudiante");
        System.out.println("5. Eliminar estudiante");
        System.out.println("6. Salir");
        System.out.print("Elige una opción: ");
    }

    private static int leerEntero() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Por favor, ingresa un número válido: ");
            }
        }
    }

    private static void crearEstudiante() {
        System.out.println("--- Crear Estudiante ---");
        System.out.print("ID: ");
        int id = leerEntero();

        while (controller.idExiste(id)) {
            System.out.print("Ese ID ya existe, ingresa otro: ");
            id = leerEntero();
        }

        System.out.print("Apellido: ");
        String apellido = leerTextoNoVacio();

        System.out.print("Nombre: ");
        String nombre = leerTextoNoVacio();

        System.out.print("Edad: ");
        int edad = leerEdadValida();

        controller.crearEstudiante(id, apellido, nombre, edad);
        System.out.println("Estudiante creado.");
        esperarEnter();
    }

    private static void listarEstudiantes() {
        System.out.println("--- Lista de Estudiantes ---");
        for (Estudiante e : controller.obtenerTodos()) {
            System.out.printf("%d - %s %s - Edad: %d\n",
                    e.getIdEstudiante(), e.getApellido(), e.getNombre(), e.getEdad());
        }
        esperarEnter();
    }

    private static void buscarEstudiantePorId() {
        System.out.print("ID del estudiante a buscar: ");
        int id = leerEntero();

        Estudiante e = controller.buscarEstudiante(id);
        if (e != null) {
            System.out.printf("Encontrado: %d - %s %s - Edad: %d\n",
                    e.getIdEstudiante(), e.getApellido(), e.getNombre(), e.getEdad());
        } else {
            System.out.println("Estudiante no encontrado.");
        }
        esperarEnter();
    }

    private static void actualizarEstudiante() {
        System.out.print("ID del estudiante a actualizar: ");
        int id = leerEntero();

        Estudiante e = controller.buscarEstudiante(id);
        if (e == null) {
            System.out.println("No existe estudiante con ese ID.");
            esperarEnter();
            return;
        }

        System.out.println("Actualizando datos para: " + e.getApellido() + " " + e.getNombre());

        System.out.print("Nuevo apellido: ");
        String apellido = leerTextoNoVacio();

        System.out.print("Nuevo nombre: ");
        String nombre = leerTextoNoVacio();

        System.out.print("Nueva edad: ");
        int edad = leerEdadValida();

        if (controller.actualizarEstudiante(id, apellido, nombre, edad)) {
            System.out.println("Actualización exitosa.");
        } else {
            System.out.println("Error actualizando estudiante.");
        }
        esperarEnter();
    }

    private static void eliminarEstudiante() {
        System.out.print("ID del estudiante a eliminar: ");
        int id = leerEntero();

        if (controller.eliminarEstudiante(id)) {
            System.out.println("Estudiante eliminado.");
        } else {
            System.out.println("No se encontró estudiante con ese ID.");
        }
        esperarEnter();
    }

    private static String leerTextoNoVacio() {
        String texto;
        do {
            texto = scanner.nextLine().trim();
            if (texto.isEmpty()) System.out.print("No puede estar vacío. Intenta de nuevo: ");
        } while (texto.isEmpty());
        return texto;
    }

    private static int leerEdadValida() {
        int edad;
        do {
            edad = leerEntero();
            if (edad < 1 || edad > 120) {
                System.out.print("Edad inválida. Debe estar entre 1 y 120: ");
            }
        } while (edad < 1 || edad > 120);
        return edad;
    }

    private static void esperarEnter() {
        System.out.println("Presiona Enter para continuar...");
        scanner.nextLine();
    }
}
