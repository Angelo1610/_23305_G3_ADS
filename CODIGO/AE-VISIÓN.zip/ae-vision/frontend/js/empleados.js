import {
  getToken, getRol, getPayload,
  cargarNavbar, protegerRuta, verificarRol, limpiarFormulario
} from './utils.js';

const API = 'http://localhost:3000/api/employees';
const token = getToken();

protegerRuta();
verificarRol('administrador');

let idActual = null;

document.addEventListener('DOMContentLoaded', async () => {
  await cargarNavbar();
  await listarEmpleados();

  const script = document.createElement('script');
  script.type = 'module';
  script.src = '../js/navbar.js';
  document.body.appendChild(script);
});

async function listarEmpleados() {
  const res = await fetch(API, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const empleados = await res.json();

  const tbody = document.getElementById('tabla-empleados');
  tbody.innerHTML = '';

  empleados.forEach(emp => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${emp.nombre}</td>
      <td>${emp.cargo}</td>
      <td>${emp.cedula}</td>
      <td>${emp.correo}</td>
      <td>${emp.turno}</td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="editarEmpleado('${emp._id}')">Editar</button>
        <button class="btn btn-danger btn-sm" onclick="eliminarEmpleado('${emp._id}')">Eliminar</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

window.editarEmpleado = async function(id) {
  const res = await fetch(`${API}/${id}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const emp = await res.json();

  document.getElementById('idEmpleado').value = emp._id;
  document.getElementById('nombre').value = emp.nombre;
  document.getElementById('cedula').value = emp.cedula;
  document.getElementById('correo').value = emp.correo;
  document.getElementById('cargo').value = emp.cargo;
  document.getElementById('turno').value = emp.turno;

  idActual = emp._id;
  new bootstrap.Modal(document.getElementById('modalEmpleado')).show();
};

window.eliminarEmpleado = async function(id) {
  if (!confirm('¿Eliminar este empleado?')) return;

  const res = await fetch(`${API}/${id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });

  const data = await res.json();
  alert(data.mensaje || 'Empleado eliminado');
  listarEmpleados();
};

document.getElementById('formEmpleado').addEventListener('submit', async e => {
  e.preventDefault();

  const empleado = {
    nombre: document.getElementById('nombre').value,
    cedula: document.getElementById('cedula').value,
    correo: document.getElementById('correo').value,
    cargo: document.getElementById('cargo').value,
    turno: document.getElementById('turno').value
  };

  const url = idActual ? `${API}/${idActual}` : API;
  const metodo = idActual ? 'PUT' : 'POST';

  const res = await fetch(url, {
    method: metodo,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(empleado)
  });

  const data = await res.json();
  alert(data.mensaje || 'Guardado correctamente');

  bootstrap.Modal.getInstance(document.getElementById('modalEmpleado')).hide();
  limpiarFormulario('formEmpleado');
  idActual = null;
  listarEmpleados();
});
