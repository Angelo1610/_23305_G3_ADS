import {
  getToken, getRol, getPayload,
  cargarNavbar, protegerRuta, verificarRol, limpiarFormulario
} from './utils.js';

const API_VENTAS = 'http://localhost:3000/api/ventas';
const API_CLIENTES = 'http://localhost:3000/api/clientes';
const token = getToken();

protegerRuta();
verificarRol('administrador');

document.addEventListener('DOMContentLoaded', async () => {
  await cargarNavbar();
  await cargarClientes();
  await listarVentas();
  await cargarNavbar();

// Cargar navbar.js dinámicamente
const script = document.createElement('script');
script.type = 'module';
script.src = '../js/navbar.js';
document.body.appendChild(script);

});

async function cargarClientes() {
  const res = await fetch(API_CLIENTES, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const clientes = await res.json();

  const select = document.getElementById('cliente');
  select.innerHTML = '<option value="">Seleccione...</option>';
  clientes.forEach(c => {
    const opt = document.createElement('option');
    opt.value = c._id;
    opt.textContent = c.nombre;
    select.appendChild(opt);
  });
}

async function listarVentas() {
  const res = await fetch(API_VENTAS, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const ventas = await res.json();

  const tbody = document.getElementById('tabla-ventas');
  tbody.innerHTML = '';

  ventas.forEach(v => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${new Date(v.fecha).toLocaleDateString()}</td>
      <td>${v.cliente?.nombre || '-'}</td>
      <td>$${v.total.toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });
}

document.getElementById('formVenta').addEventListener('submit', async e => {
  e.preventDefault();

  const venta = {
    cliente: document.getElementById('cliente').value,
    total: parseFloat(document.getElementById('total').value)
  };

  const res = await fetch(API_VENTAS, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(venta)
  });

  const data = await res.json();
  alert(data.mensaje || 'Venta registrada');

  bootstrap.Modal.getInstance(document.getElementById('modalVenta')).hide();
  limpiarFormulario('formVenta');
  listarVentas();
});
