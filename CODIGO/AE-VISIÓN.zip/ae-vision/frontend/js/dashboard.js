// dashboard.js
import { cargarNavbar, protegerRuta, getNombre, getRol } from './utils.js';

protegerRuta();

document.addEventListener('DOMContentLoaded', async () => {
  // Carga navbar.html
  await cargarNavbar();

  // Luego carga navbar.js
  const script = document.createElement('script');
  script.type = 'module';
  script.src = '../js/navbar.js';
  document.body.appendChild(script);

  const nombre = getNombre();
  document.getElementById('bienvenida').textContent = `Bienvenido, ${nombre}`;

  const rol = getRol();
  const modulos = document.getElementById('modulos-disponibles');
  const tarjetas = [];

  if (rol === 'administrador') {
    tarjetas.push(
      crearTarjeta('Inventario', 'Gestiona productos', 'inventario.html'),
      crearTarjeta('Empleados', 'Controla personal', 'empleados.html'),
      crearTarjeta('Clientes', 'Lista y registra clientes', 'clientes.html'),
      crearTarjeta('Ventas', 'Registra ventas', 'ventas.html'),
      crearTarjeta('Pedidos', 'Solicitudes de productos', 'pedidos.html'),
      crearTarjeta('Reportes', 'Resumen y estadísticas', 'reportes.html')
    );
  }

  if (rol === 'cliente') {
    tarjetas.push(
      crearTarjeta('Mis Pedidos', 'Consulta y haz pedidos', 'pedidos.html'),
      crearTarjeta('Mi Perfil', 'Datos personales', 'perfil.html')
    );
  }

  tarjetas.forEach(t => modulos.appendChild(t));
});

function crearTarjeta(titulo, descripcion, enlace) {
  const div = document.createElement('div');
  div.classList.add('col');
  div.innerHTML = `
    <div class="card h-100 shadow-sm">
      <div class="card-body">
        <h5 class="card-title">${titulo}</h5>
        <p class="card-text">${descripcion}</p>
        <a href="${enlace}" class="btn btn-primary w-100">Ir</a>
      </div>
    </div>
  `;
  return div;
}
