document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('formRegistro');
  const mensaje = document.getElementById('mensaje');

  const mostrarMensaje = (texto, tipo = 'success') => {
    mensaje.textContent = texto;
    mensaje.className = `alert alert-${tipo} mt-3`;
    mensaje.classList.remove('d-none');
  };

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const nombre = document.getElementById('nombre').value.trim();
    const correo = document.getElementById('correo').value.trim();
    const contrasena = document.getElementById('contrasena').value.trim();
    const rol = document.getElementById('rol').value;

    if (!nombre || !correo || !contrasena || !rol) {
      mostrarMensaje('Por favor, completa todos los campos.', 'danger');
      return;
    }

    try {
      const res = await fetch('http://localhost:3000/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nombre, correo, contrasena, rol })
      });

      const data = await res.json();
      console.log("Respuesta del servidor:", data);

      if (res.ok) {
        mostrarMensaje('✅ Registro exitoso. Redirigiendo...', 'success');
        localStorage.setItem('token', data.token);
        setTimeout(() => {
          window.location.href = 'dashboard.html';
        }, 2000);
      } else {
        mostrarMensaje(data.mensaje || '❌ Error al registrarse.', 'danger');
      }
    } catch (error) {
      console.error("Error de red:", error);
      mostrarMensaje('❌ Error de red o conexión con el servidor.', 'danger');
    }
  });
});
