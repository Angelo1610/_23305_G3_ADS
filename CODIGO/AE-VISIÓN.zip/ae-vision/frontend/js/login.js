document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('form-login');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const correo = document.getElementById('correo').value;
    const contrasena = document.getElementById('contrasena').value;

    try {
      const res = await fetch('http://localhost:3000/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ correo, contrasena })
      });

      const data = await res.json();

      if (res.ok) {
        localStorage.setItem('token', data.token);
        alert('Inicio de sesión exitoso.');
        location.href = '../pages/dashboard.html';
      } else {
        alert(data.mensaje || 'Error al iniciar sesión.');
      }
    } catch (err) {
      alert('Error de conexión con el servidor.');
      console.error(err);
    }
  });
});
