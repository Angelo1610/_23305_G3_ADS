import {
  getToken, getRol, getUserId,
  cargarNavbar, protegerRuta, verificarRol, limpiarFormulario
} from './utils.js';

const API_PEDIDOS = 'http://localhost:3000/api/pedidos';
const token = getToken();

protegerRuta();

document.addEventListener('DOMContentLoaded', async () => {
  await cargarNavbar();
  await listarPedidos();
  const script = document.createElement('script');
script.type = 'module';
script.src = '../js/navbar.js';
document.body.appendChild(script);
});

async function listarPedidos() {
  const rol = getRol();
  const res = await fetch(API_PEDIDOS, {
    headers: { Authorization: `Bearer ${token}` }
  });

  let pedidos = await res.json();

  if (rol === 'cliente') {
    const userId = getUserId();
    pedidos = pedidos.filter(p => p.cliente === userId);
  }

  const tbody = document.getElementById('tabla-pedidos');
  tbody.innerHTML = '';

  pedidos.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${new Date(p.fecha).toLocaleDateString()}</td>
      <td>${p.producto}</td>
      <td>${p.cantidad}</td>
      <td>${p.estado}</td>
    `;
    tbody.appendChild(tr);
  });
}

document.getElementById('formPedido')?.addEventListener('submit', async e => {
  e.preventDefault();

  const pedido = {
    producto: document.getElementById('producto').value,
    cantidad: parseInt(document.getElementById('cantidad').value)
  };

  const res = await fetch(API_PEDIDOS, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(pedido)
  });

  const data = await res.json();
  alert(data.mensaje || 'Pedido enviado');

  bootstrap.Modal.getInstance(document.getElementById('modalPedido')).hide();
  limpiarFormulario('formPedido');
  listarPedidos();
});
