// Obtener token del localStorage
export function getToken() {
  return localStorage.getItem('token');
}

// Decodificar payload del token
export function getPayload() {
  const token = getToken();
  if (!token) return null;
  return JSON.parse(atob(token.split('.')[1]));
}

// Obtener rol actual
export function getRol() {
  const payload = getPayload();
  return payload?.rol || '';
}

// Obtener ID de usuario actual
export function getUserId() {
  const payload = getPayload();
  return payload?.id || '';
}

// Obtener nombre del usuario
export function getNombre() {
  const payload = getPayload();
  return payload?.nombre || '';
}

// Cargar navbar en vistas
export async function cargarNavbar() {
  const res = await fetch('../pages/navbar.html');
  const html = await res.text();
  document.getElementById('navbar-container').innerHTML = html;
}

// Redireccionar si no hay token
export function protegerRuta() {
  if (!getToken()) {
    location.href = '../pages/login.html';
  }
}

// Redireccionar si el rol no coincide
export function verificarRol(requerido) {
  if (getRol() !== requerido) {
    location.href = '../pages/dashboard.html';
  }
}

// Limpiar un formulario completo
export function limpiarFormulario(formId) {
  const form = document.getElementById(formId);
  if (form) form.reset();
}

// Cerrar sesión
export function cerrarSesion() {
  localStorage.removeItem('token');
  location.href = '../pages/login.html';
}
