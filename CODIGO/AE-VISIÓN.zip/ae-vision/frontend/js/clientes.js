import {
  getToken, cargarNavbar, protegerRuta, verificarRol, limpiarFormulario
} from './utils.js';

const API = 'http://localhost:3000/api/clients'; // Asegúrate de que coincida con tu route base
const token = getToken();

protegerRuta();
verificarRol('administrador');

let idActual = null;

document.addEventListener('DOMContentLoaded', async () => {
  await cargarNavbar();
  await listarClientes();

  // Cargar navbar dinámicamente si hace falta
  const script = document.createElement('script');
  script.type = 'module';
  script.src = '../js/navbar.js';
  document.body.appendChild(script);
});

async function listarClientes() {
  const res = await fetch(API, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const clientes = await res.json();

  const tbody = document.getElementById('tabla-clientes');
  tbody.innerHTML = '';

  clientes.forEach(c => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${c.nombre}</td>
      <td>${c.cedula}</td>
      <td>${c.correo}</td>
      <td>${c.telefono}</td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="editarCliente('${c._id}')">Editar</button>
        <button class="btn btn-danger btn-sm" onclick="eliminarCliente('${c._id}')">Eliminar</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

window.editarCliente = async function (id) {
  const res = await fetch(`${API}/${id}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const cliente = await res.json();

  document.getElementById('idCliente').value = cliente._id;
  document.getElementById('nombre').value = cliente.nombre;
  document.getElementById('cedula').value = cliente.cedula;
  document.getElementById('correo').value = cliente.correo;
  document.getElementById('telefono').value = cliente.telefono;

  idActual = cliente._id;
  new bootstrap.Modal(document.getElementById('modalCliente')).show();
};

window.eliminarCliente = async function (id) {
  if (!confirm('¿Eliminar este cliente?')) return;

  const res = await fetch(`${API}/${id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });

  const data = await res.json();
  alert(data.mensaje || 'Cliente eliminado');
  listarClientes();
};

document.getElementById('formCliente').addEventListener('submit', async e => {
  e.preventDefault();

  const cliente = {
    nombre: document.getElementById('nombre').value,
    cedula: document.getElementById('cedula').value,
    correo: document.getElementById('correo').value,
    telefono: document.getElementById('telefono').value
  };

  const url = idActual ? `${API}/${idActual}` : API;
  const metodo = idActual ? 'PUT' : 'POST';

  const res = await fetch(url, {
    method: metodo,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(cliente)
  });

  const data = await res.json();
  alert(data.mensaje || 'Guardado exitosamente');

  bootstrap.Modal.getInstance(document.getElementById('modalCliente')).hide();
  limpiarFormulario('formCliente');
  idActual = null;
  listarClientes();
});
