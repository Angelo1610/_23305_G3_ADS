import {
  getToken, cargarNavbar, protegerRuta, verificarRol, limpiarFormulario
} from './utils.js';

const API = 'http://localhost:3000/api/products';
const token = getToken();

protegerRuta();
verificarRol('administrador');

let idActual = null;

document.addEventListener('DOMContentLoaded', async () => {
  await cargarNavbar();
  await listarProductos();

  // Cargar navbar dinámicamente si hace falta
  const script = document.createElement('script');
  script.type = 'module';
  script.src = '../js/navbar.js';
  document.body.appendChild(script);
});

async function listarProductos() {
  const res = await fetch(API, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const productos = await res.json();

  const tbody = document.getElementById('tabla-productos');
  tbody.innerHTML = '';

  productos.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${p.nombre}</td>
      <td>${p.codigo}</td>
      <td>${p.categoria}</td>
      <td>${p.cantidad}</td>
      <td>${p.ubicacion}</td>
      <td>${p.precio.toFixed(2)}</td>
      <td>
        <button class="btn btn-warning btn-sm" onclick="editarProducto('${p._id}')">Editar</button>
        <button class="btn btn-danger btn-sm" onclick="eliminarProducto('${p._id}')">Eliminar</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

window.editarProducto = async function (id) {
  const res = await fetch(`${API}/${id}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const producto = await res.json();

  document.getElementById('idProducto').value = producto._id;
  document.getElementById('nombre').value = producto.nombre;
  document.getElementById('codigo').value = producto.codigo;
  document.getElementById('categoria').value = producto.categoria;
  document.getElementById('cantidad').value = producto.cantidad;
  document.getElementById('ubicacion').value = producto.ubicacion;
  document.getElementById('precio').value = producto.precio;

  idActual = producto._id;
  new bootstrap.Modal(document.getElementById('modalProducto')).show();
};

window.eliminarProducto = async function (id) {
  if (!confirm('¿Eliminar este producto?')) return;

  const res = await fetch(`${API}/${id}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` }
  });

  const data = await res.json();
  alert(data.mensaje || 'Producto eliminado');
  listarProductos();
};

document.getElementById('formProducto').addEventListener('submit', async e => {
  e.preventDefault();

  const producto = {
    nombre: document.getElementById('nombre').value,
    codigo: document.getElementById('codigo').value,
    categoria: document.getElementById('categoria').value,
    cantidad: parseInt(document.getElementById('cantidad').value),
    ubicacion: document.getElementById('ubicacion').value,
    precio: parseFloat(document.getElementById('precio').value)
  };

  const url = idActual ? `${API}/${idActual}` : API;
  const metodo = idActual ? 'PUT' : 'POST';

  const res = await fetch(url, {
    method: metodo,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(producto)
  });

  const data = await res.json();
  alert(data.mensaje || 'Guardado exitosamente');

  bootstrap.Modal.getInstance(document.getElementById('modalProducto')).hide();
  limpiarFormulario('formProducto');
  idActual = null;
  listarProductos();
});
