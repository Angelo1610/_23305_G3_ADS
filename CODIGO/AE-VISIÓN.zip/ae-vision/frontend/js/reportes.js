import {
  getToken, getRol,
  cargarNavbar, protegerRuta, verificarRol
} from './utils.js';

const API_REPORTES = 'http://localhost:3000/api/reportes';
const token = getToken();

protegerRuta();
verificarRol('administrador');

document.addEventListener('DOMContentLoaded', async () => {
  await cargarNavbar();
  await generarReporteVentas();
  const script = document.createElement('script');
script.type = 'module';
script.src = '../js/navbar.js';
document.body.appendChild(script);
});

async function generarReporteVentas() {
  try {
    const res = await fetch(`${API_REPORTES}/ventas`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();

    const tbody = document.getElementById('tabla-reportes');
    tbody.innerHTML = '';

    data.forEach(r => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${r.producto}</td>
        <td>${r.totalCantidad}</td>
        <td>$${r.totalIngresos.toFixed(2)}</td>
      `;
      tbody.appendChild(tr);
    });

  } catch (err) {
    alert('Error al generar el reporte');
  }
}
