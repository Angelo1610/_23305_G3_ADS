// navbar.js
import { getToken, getPayload, cerrarSesion } from './utils.js';

document.addEventListener('DOMContentLoaded', () => {
  const token = getToken();
  if (!token) location.href = '../pages/login.html';

  const payload = getPayload();
  const rol = payload.rol;
  const nombre = payload.nombre;

  const nombreUsuario = document.getElementById('usuario-nombre');
  if (nombreUsuario) nombreUsuario.textContent = nombre;

  const enlaces = document.getElementById('enlaces-rol');
  if (rol === 'administrador') {
    enlaces.innerHTML = `
      <li class="nav-item"><a class="nav-link" href="inventario.html">Inventario</a></li>
      <li class="nav-item"><a class="nav-link" href="empleados.html">Empleados</a></li>
      <li class="nav-item"><a class="nav-link" href="clientes.html">Clientes</a></li>
      <li class="nav-item"><a class="nav-link" href="ventas.html">Ventas</a></li>
      <li class="nav-item"><a class="nav-link" href="pedidos.html">Pedidos</a></li>
      <li class="nav-item"><a class="nav-link" href="reportes.html">Reportes</a></li>
    `;
  } else if (rol === 'cliente') {
    enlaces.innerHTML = `
      <li class="nav-item"><a class="nav-link" href="pedidos.html">Mis Pedidos</a></li>
      <li class="nav-item"><a class="nav-link" href="perfil.html">Mi Perfil</a></li>
    `;
  }

  // ✅ Esperar que el botón esté disponible en el DOM cargado dinámicamente
  const esperarBoton = setInterval(() => {
    const btn = document.getElementById('btn-cerrar-sesion');
    if (btn) {
      btn.addEventListener('click', cerrarSesion);
      clearInterval(esperarBoton);
    }
  }, 100);
});
