import {
  getToken, getUserId, getRol,
  cargarNavbar, protegerRuta, verificarRol, limpiarFormulario
} from './utils.js';

const token = getToken();
const API = 'http://localhost:3000/api';

protegerRuta();
verificarRol('cliente');

document.addEventListener('DOMContentLoaded', async () => {
  await cargarNavbar();
  await cargarPerfil();
  const script = document.createElement('script');
script.type = 'module';
script.src = '../js/navbar.js';
document.body.appendChild(script);
});

async function cargarPerfil() {
  const res = await fetch(`${API}/users/${getUserId()}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const user = await res.json();
  document.getElementById('nombre').value = user.nombre;
  document.getElementById('correo').value = user.correo;
}

document.getElementById('formPerfil').addEventListener('submit', async e => {
  e.preventDefault();

  const datos = {
    nombre: document.getElementById('nombre').value,
    correo: document.getElementById('correo').value
  };

  const contrasena = document.getElementById('contrasena').value;
  if (contrasena) datos.contrasena = contrasena;

  const res = await fetch(`${API}/users/${getUserId()}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    },
    body: JSON.stringify(datos)
  });

  const result = await res.json();
  alert(result.mensaje || 'Perfil actualizado');
  document.getElementById('contrasena').value = '';
});
