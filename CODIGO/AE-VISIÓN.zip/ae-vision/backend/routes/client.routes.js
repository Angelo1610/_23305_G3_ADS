const express = require('express');
const router = express.Router();
const clientCtrl = require('../controllers/client.controller');
const { verifyToken, isAdmin } = require('../middlewares/auth.middleware');
router.get('/', verifyToken, isAdmin, clientCtrl.getAll);
router.post('/', verifyToken, isAdmin, clientCtrl.create);
router.put('/:id', verifyToken, isAdmin, clientCtrl.update);
router.delete('/:id', verifyToken, isAdmin, clientCtrl.remove);

module.exports = router;
