const express = require('express');
const router = express.Router();
const userCtrl = require('../controllers/user.controller');
const { verifyToken } = require('../middlewares/auth.middleware');
router.get('/profile', verifyToken, userCtrl.getProfile);
router.put('/profile', verifyToken, userCtrl.updateProfile);

module.exports = router;
