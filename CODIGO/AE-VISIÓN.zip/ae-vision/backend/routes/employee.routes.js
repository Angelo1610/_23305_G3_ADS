const express = require('express');
const router = express.Router();
const employeeCtrl = require('../controllers/employee.controller');
const { verifyToken, isAdmin } = require('../middlewares/auth.middleware');

router.post('/', verifyToken, isAdmin, employeeCtrl.create);
router.put('/:id', verifyToken, isAdmin, employeeCtrl.update);
router.delete('/:id', verifyToken, isAdmin, employeeCtrl.remove);
router.get('/', verifyToken, isAdmin, employeeCtrl.getAll); // 👈 AGREGAR ESTA


module.exports = router;
