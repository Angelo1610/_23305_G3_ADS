const express = require('express');
const router = express.Router();
const reportCtrl = require('../controllers/report.controller');
const { verifyToken, isAdmin } = require('../middlewares/auth.middleware');

router.get('/', verifyToken, isAdmin, reportCtrl.generateReport);

module.exports = router;
