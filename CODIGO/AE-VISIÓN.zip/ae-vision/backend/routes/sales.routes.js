const express = require('express');
const router = express.Router();
const salesCtrl = require('../controllers/sales.controller');
const { verifyToken, isAdmin } = require('../middlewares/auth.middleware');

router.get('/', verifyToken, isAdmin, salesCtrl.getAll);
router.post('/', verifyToken, isAdmin, salesCtrl.create);
router.put('/:id', verifyToken, isAdmin, salesCtrl.update);
router.delete('/:id', verifyToken, isAdmin, salesCtrl.remove);

module.exports = router;
