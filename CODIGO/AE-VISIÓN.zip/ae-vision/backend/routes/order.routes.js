const express = require('express');
const router = express.Router();
const orderCtrl = require('../controllers/order.controller');
const { verifyToken } = require('../middlewares/auth.middleware');
router.get('/', verifyToken, orderCtrl.getAll);
router.post('/', verifyToken, orderCtrl.create);

module.exports = router;
