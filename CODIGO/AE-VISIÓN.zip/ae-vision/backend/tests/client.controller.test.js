require('dotenv').config({ path: '.env.test' });

const request = require('supertest');
const app = require('../app');
const mongoose = require('mongoose');
const Client = require('../models/Client');

let token = '';
let clienteId = '';

beforeAll(async () => {
  await mongoose.connect(process.env.MONGO_URI);

  // Crear usuario admin si no existe y loguear
  await request(app)
    .post('/api/auth/register')
    .send({
      nombre: 'Admin',
      correo: 'admin@example.com',
      contrasena: 'admin123',
      rol: 'administrador'
    });

  const res = await request(app)
    .post('/api/auth/login')
    .send({ correo: 'admin@example.com', contrasena: 'admin123' });

  token = res.body.token;
});

afterAll(async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.disconnect();
});

describe('Pruebas del controlador de Cliente', () => {
  test('Crear un nuevo cliente', async () => {
    const res = await request(app)
      .post('/api/clients')
      .set('Authorization', `Bearer ${token}`)
      .send({
        nombre: 'Juan Test',
        cedula: '1234567890',
        correo: 'juan@test.com',
        telefono: '0999999999'
      });

    expect(res.statusCode).toBe(201);
    expect(res.body.nombre).toBe('Juan Test');
    clienteId = res.body._id;
  });

  test('Listar clientes', async () => {
    const res = await request(app)
      .get('/api/clients')
      .set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('Actualizar cliente', async () => {
    const res = await request(app)
      .put(`/api/clients/${clienteId}`)
      .set('Authorization', `Bearer ${token}`)
      .send({ nombre: 'Juan Actualizado' });

    expect(res.statusCode).toBe(200);
    expect(res.body.nombre).toBe('Juan Actualizado');
  });

  test('Eliminar cliente', async () => {
    const res = await request(app)
      .delete(`/api/clients/${clienteId}`)
      .set('Authorization', `Bearer ${token}`);

    expect(res.statusCode).toBe(200);
    expect(res.body.mensaje).toBe('Cliente eliminado.');
  });
});
