describe('Prueba vacía - Usuarios', () => {
  it('Debe pasar esta prueba vacía', () => {
    expect(true).toBe(true);
  });
});
