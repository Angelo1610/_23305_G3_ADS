require('dotenv').config({ path: '../.env.test' });  // 👈 ruta relativa correcta desde tests/

const mongoose = require('mongoose');

console.log("Conectando a Mongo...");
console.log("URI cargada:", process.env.MONGO_URI);

mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ Conexión exitosa");
    mongoose.disconnect();
  })
  .catch(err => {
    console.error("❌ Error conectando a Mongo:", err.message);
  });
