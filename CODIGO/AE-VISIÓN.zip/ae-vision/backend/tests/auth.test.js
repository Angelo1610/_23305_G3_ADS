require('dotenv').config({ path: '.env.test' });

const mongoose = require('mongoose');
const request = require('supertest');
const app = require('../app');

jest.setTimeout(20000);

describe('Autenticación - AE Vision', () => {
  beforeAll(async () => {
    await mongoose.connect(process.env.MONGO_URI);
  });

  afterAll(async () => {
    await mongoose.connection.dropDatabase();
    await mongoose.disconnect();
  });

  test('Debe registrar un nuevo usuario', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({
        nombre: 'Test User',
        correo: 'testuser@example.com',
        contrasena: '123456',
        rol: 'cliente'
      });

    expect(res.statusCode).toBe(201);
    expect(res.body.mensaje).toBeDefined();
  });

  test('Debe loguearse con credenciales válidas', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        correo: 'testuser@example.com',
        contrasena: '123456'
      });

    expect(res.statusCode).toBe(200);
    expect(res.body.token).toBeDefined();
  });
});
