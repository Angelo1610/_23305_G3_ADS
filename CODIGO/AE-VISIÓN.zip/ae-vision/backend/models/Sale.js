const mongoose = require('mongoose');

const saleSchema = new mongoose.Schema({
  cliente: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  productos: [{
    producto: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    cantidad: { type: Number, required: true }
  }],
  total: { type: Number, required: true },
  fecha: { type: Date, default: Date.now },
  estado: { type: String, enum: ['pagado', 'pendiente'], default: 'pagado' }
}, { timestamps: true });

module.exports = mongoose.model('Sale', saleSchema);
