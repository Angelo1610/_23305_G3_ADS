const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  cedula: { type: String, required: true, unique: true },
  correo: { type: String },
  cargo: { type: String, required: true },
  turno: { type: String, enum: ['mañana', 'tarde', 'noche'], required: true }
}, { timestamps: true });

module.exports = mongoose.model('Employee', employeeSchema);
