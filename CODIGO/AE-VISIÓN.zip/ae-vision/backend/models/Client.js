const mongoose = require('mongoose');

const clientSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  cedula: { type: String, required: true, unique: true },
  correo: { type: String, required: true },
  telefono: { type: String }
}, { timestamps: true });

module.exports = mongoose.model('Client', clientSchema);
