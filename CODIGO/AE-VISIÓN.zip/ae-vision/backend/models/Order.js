const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  cliente: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  productos: [{
    producto: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    cantidad: { type: Number, required: true }
  }],
  direccionEnvio: { type: String, required: true },
  estado: { type: String, enum: ['pendiente', 'enviado', 'entregado'], default: 'pendiente' }
}, { timestamps: true });

module.exports = mongoose.model('Order', orderSchema);
