const User = require('../models/User');

exports.getProfile = async (req, res) => {
  try {
    const usuario = await User.findById(req.user.id).select('-contrasena');
    res.json(usuario);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al obtener perfil.' });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const { nombre, correo, contrasena } = req.body;
    const updateData = { nombre, correo };
    if (contrasena) updateData.contrasena = contrasena;

    const usuario = await User.findByIdAndUpdate(req.user.id, updateData, { new: true });
    res.json({ mensaje: 'Perfil actualizado.', usuario });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al actualizar perfil.' });
  }
};
