const Client = require('../models/Client');

exports.getAll = async (req, res) => {
  const clientes = await Client.find();
  res.json(clientes);
};

exports.create = async (req, res) => {
  const { nombre, cedula, correo, telefono } = req.body;
  const existe = await Client.findOne({ cedula });
  if (existe) return res.status(400).json({ mensaje: 'Cliente ya registrado.' });

  const cliente = new Client({ nombre, cedula, correo, telefono });
  await cliente.save();
  res.status(201).json(cliente);
};

exports.update = async (req, res) => {
  const cliente = await Client.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(cliente);
};

exports.remove = async (req, res) => {
  await Client.findByIdAndDelete(req.params.id);
  res.json({ mensaje: 'Cliente eliminado.' });
};
