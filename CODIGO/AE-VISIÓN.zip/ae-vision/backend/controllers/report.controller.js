const Sale = require('../models/Sale');
const Product = require('../models/Product');
const Client = require('../models/Client');
const Employee = require('../models/Employee');

exports.generateReport = async (req, res) => {
  try {
    const { tipo } = req.query;

    switch (tipo) {
      case 'ventas':
        return res.json(await Sale.find().populate('cliente'));
      case 'productos':
        return res.json(await Product.find());
      case 'clientes':
        return res.json(await Client.find());
      case 'empleados':
        return res.json(await Employee.find());
      default:
        return res.status(400).json({ mensaje: 'Tipo de reporte inválido.' });
    }
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al generar reporte.' });
  }
};
