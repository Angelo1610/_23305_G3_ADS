const Product = require('../models/Product');

exports.getAll = async (req, res) => {
  const productos = await Product.find();
  res.json(productos);
};

exports.create = async (req, res) => {
  try {
    const { nombre, codigo, categoria, cantidad, ubicacion, precio } = req.body;
    const existe = await Product.findOne({ codigo });
    if (existe) return res.status(400).json({ mensaje: 'Producto ya existe.' });

    const producto = new Product({ nombre, codigo, categoria, cantidad, ubicacion, precio });
    await producto.save();
    res.status(201).json(producto);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al crear producto.' });
  }
};

exports.update = async (req, res) => {
  try {
    const producto = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(producto);
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al actualizar producto.' });
  }
};

exports.remove = async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ mensaje: 'Producto eliminado.' });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al eliminar producto.' });
  }
};
