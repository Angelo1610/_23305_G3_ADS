const Employee = require('../models/Employee');

exports.getAll = async (req, res) => {
  const empleados = await Employee.find();
  res.json(empleados);
};

exports.create = async (req, res) => {
  const { nombre, cedula, correo, cargo, turno } = req.body;
  const existe = await Employee.findOne({ cedula });
  if (existe) return res.status(400).json({ mensaje: 'Trabajador ya registrado.' });

  const empleado = new Employee({ nombre, cedula, correo, cargo, turno });
  await empleado.save();
  res.status(201).json(empleado);
};

exports.update = async (req, res) => {
  const empleado = await Employee.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(empleado);
};

exports.remove = async (req, res) => {
  await Employee.findByIdAndDelete(req.params.id);
  res.json({ mensaje: 'Empleado eliminado.' });
};
