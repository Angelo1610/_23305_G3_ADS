const Sale = require('../models/Sale');

exports.getAll = async (req, res) => {
  const ventas = await Sale.find().populate('cliente productos.producto');
  res.json(ventas);
};

exports.create = async (req, res) => {
  const { cliente, productos, total, estado } = req.body;
  const venta = new Sale({ cliente, productos, total, estado });
  await venta.save();
  res.status(201).json(venta);
};

exports.update = async (req, res) => {
  const venta = await Sale.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(venta);
};

exports.remove = async (req, res) => {
  await Sale.findByIdAndDelete(req.params.id);
  res.json({ mensaje: 'Venta eliminada.' });
};
