const Order = require('../models/Order');

exports.getAll = async (req, res) => {
  const pedidos = await Order.find().populate('cliente productos.producto');
  res.json(pedidos);
};

exports.create = async (req, res) => {
  const pedido = new Order(req.body);
  await pedido.save();
  res.status(201).json(pedido);
};
