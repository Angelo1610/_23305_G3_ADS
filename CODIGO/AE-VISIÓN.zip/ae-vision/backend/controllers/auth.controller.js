const User = require('../models/User');
const Token = require('../models/Token');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '1d'; // ✅ Aquí usamos la variable correcta

exports.register = async (req, res) => {
  try {
    const { nombre, correo, contrasena, rol } = req.body;

    const existente = await User.findOne({ correo });
    if (existente) {
      return res.status(400).json({ mensaje: 'El correo ya está en uso.' });
    }

    const nuevoUsuario = new User({ nombre, correo, contrasena, rol });
    await nuevoUsuario.save();

       const token = jwt.sign(
      { id: nuevoUsuario._id, rol: nuevoUsuario.rol, nombre: nuevoUsuario.nombre },
      process.env.JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN } // ✅ Usa la constante ya definida correctamente
    );


    res.status(201).json({ token });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al registrar usuario.', error: err.message });
  }
};


exports.login = async (req, res) => {
  try {
    const { correo, contrasena } = req.body;
    const usuario = await User.findOne({ correo });
    if (!usuario || !(await usuario.validarContrasena(contrasena))) {
      return res.status(401).json({ mensaje: 'Credenciales inválidas.' });
    }

    const token = jwt.sign(
      { id: usuario._id, rol: usuario.rol, nombre: usuario.nombre },
      process.env.JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN } // ✅ Variable corregida
    );

    res.json({ token });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error en inicio de sesión.', error: err.message });
  }
};

exports.recoverPassword = async (req, res) => {
  try {
    const { correo } = req.body;
    const user = await User.findOne({ correo });
    if (!user) return res.status(404).json({ mensaje: 'Correo no registrado.' });

    const tokenString = crypto.randomBytes(32).toString('hex');
    const token = new Token({ userId: user._id, token: tokenString });
    await token.save();

    // Aquí simulas el envío (normalmente usarías nodemailer)
    res.json({ mensaje: 'Enlace de recuperación enviado.', token: tokenString });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al generar token de recuperación.', error: err.message });
  }
};

exports.resetPassword = async (req, res) => {
  try {
    const { token, nuevaContrasena } = req.body;
    const resetToken = await Token.findOne({ token });
    if (!resetToken) return res.status(400).json({ mensaje: 'Token inválido o expirado.' });

    const user = await User.findById(resetToken.userId);
    user.contrasena = nuevaContrasena;
    await user.save();
    await resetToken.deleteOne();

    res.json({ mensaje: 'Contraseña restablecida con éxito.' });
  } catch (err) {
    res.status(500).json({ mensaje: 'Error al restablecer contraseña.', error: err.message });
  }
};
