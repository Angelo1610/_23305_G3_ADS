// jest.config.js
module.exports = {
  testTimeout: 40000 // 30 segundos
};
