package logica_negocio;

/**
 * Clase que contiene la lógica de negocio para gestionar estudiantes.
 * Actúa como intermediaria entre la capa de presentación y la capa de repositorio.
 */
import datos.model.Estudiante;
import datos.repository.EstudianteRepository;

import java.util.List;

public class EstudianteService {
    private EstudianteRepository repositorio = new EstudianteRepository();  // Instancia del repositorio para acceder a los datos

    /**
     * Agrega un nuevo estudiante al sistema.
     * @param id El identificador único del estudiante.
     * @param nombre El nombre del estudiante.
     * @param edad La edad del estudiante.
     */
    public void agregarEstudiante(int id, String nombre, int edad) {
        Estudiante estudiante = new Estudiante(id, nombre, edad);  // Crea un nuevo objeto Estudiante
        repositorio.crear(estudiante);  // Almacena el estudiante en el repositorio
    }

    /**
     * Obtiene la lista de todos los estudiantes registrados.
     * @return Una lista con todos los estudiantes.
     */
    public List<Estudiante> listarEstudiantes() {
        return repositorio.leerTodos();  // Devuelve la lista de estudiantes desde el repositorio
    }

    /**
     * Busca un estudiante por su identificador único.
     * @param id El identificador del estudiante a buscar.
     * @return El objeto Estudiante si se encuentra, null en caso contrario.
     */
    public Estudiante buscarPorId(int id) {
        return repositorio.leerPorId(id);  // Busca y devuelve el estudiante con el id especificado
    }

    /**
     * Modifica los datos de un estudiante existente.
     * @param id El identificador del estudiante a modificar.
     * @param nuevoNombre El nuevo nombre del estudiante.
     * @param nuevaEdad La nueva edad del estudiante.
     */
    public void modificarEstudiante(int id, String nuevoNombre, int nuevaEdad) {
        Estudiante estudiante = repositorio.leerPorId(id);  // Busca el estudiante por su id
        if (estudiante != null) {  // Verifica si el estudiante existe
            estudiante.setNombre(nuevoNombre);  // Actualiza el nombre
            estudiante.setEdad(nuevaEdad);     // Actualiza la edad
            repositorio.actualizar(estudiante); // Guarda los cambios en el repositorio
        }
    }

    /**
     * Elimina un estudiante del sistema según su identificador.
     * @param id El identificador del estudiante a eliminar.
     */
    public void eliminarEstudiante(int id) {
        repositorio.eliminar(id);  // Elimina el estudiante con el id especificado
    }
}