package datos.model;

/**
 * Clase que representa a un estudiante con sus atributos básicos.
 */
public class Estudiante {
    private int id;              // Identificador único del estudiante
    private String nombre;       // Nombre del estudiante
    private int edad;            // Edad del estudiante

    /**
     * Constructor de la clase Estudiante.
     * @param id El identificador único del estudiante.
     * @param nombre El nombre del estudiante.
     * @param edad La edad del estudiante.
     */
    public Estudiante(int id, String nombre, int edad) {
        this.id = id;            // Asigna el identificador único
        this.nombre = nombre;    // Asigna el nombre
        this.edad = edad;        // Asigna la edad
    }

    /**
     * Obtiene el identificador del estudiante.
     * @return El valor del identificador (id).
     */
    public int getId() {
        return id;
    }

    /**
     * Establece el identificador del estudiante.
     * @param id El nuevo valor del identificador.
     */
    public void setId(int id) {
        this.id = id;            // Actualiza el identificador
    }

    /**
     * Obtiene el nombre del estudiante.
     * @return El nombre del estudiante.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre del estudiante.
     * @param nombre El nuevo nombre del estudiante.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;    // Actualiza el nombre
    }

    /**
     * Obtiene la edad del estudiante.
     * @return La edad del estudiante.
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Establece la edad del estudiante.
     * @param edad La nueva edad del estudiante.
     */
    public void setEdad(int edad) {
        this.edad = edad;        // Actualiza la edad
    }

    /**
     * Devuelve una representación en cadena del objeto Estudiante.
     * @return Una cadena con los valores de id, nombre y edad.
     */
    @Override
    public String toString() {
        return "Estudiante{id=" + id + ", nombre='" + nombre + '\'' + ", edad=" + edad + '}';
    }
}