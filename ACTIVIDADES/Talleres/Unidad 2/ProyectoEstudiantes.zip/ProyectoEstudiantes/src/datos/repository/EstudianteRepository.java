package datos.repository;

/**
 * Clase que gestiona el acceso y almacenamiento de los estudiantes en una lista en memoria.
 * Actúa como la capa de repositorio en la arquitectura de 3 capas.
 */
import datos.model.Estudiante;

import java.util.ArrayList;
import java.util.List;

public class EstudianteRepository {
    private List<Estudiante> estudiantes = new ArrayList<>();  // Lista que almacena los estudiantes

    /**
     * Agrega un nuevo estudiante a la lista.
     * @param estudiante El objeto Estudiante a agregar.
     */
    public void crear(Estudiante estudiante) {
        estudiantes.add(estudiante);  // Añade el estudiante a la lista
    }

    /**
     * Obtiene una copia de la lista de todos los estudiantes.
     * @return Una nueva lista con todos los estudiantes registrados.
     */
    public List<Estudiante> leerTodos() {
        return new ArrayList<>(estudiantes);  // Devuelve una copia para evitar modificaciones externas
    }

    /**
     * Busca un estudiante por su identificador único (id).
     * @param id El identificador del estudiante a buscar.
     * @return El objeto Estudiante si se encuentra, null en caso contrario.
     */
    public Estudiante leerPorId(int id) {
        return estudiantes.stream()
                .filter(e -> e.getId() == id)  // Filtra por el identificador
                .findFirst()                   // Toma el primer resultado
                .orElse(null);                 // Devuelve null si no se encuentra
    }

    /**
     * Actualiza los datos de un estudiante existente en la lista.
     * @param estudiante El objeto Estudiante con los datos actualizados.
     */
    public void actualizar(Estudiante estudiante) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == estudiante.getId()) {  // Busca por identificador
                estudiantes.set(i, estudiante);  // Actualiza el estudiante
                return;  // Sale del método tras la actualización
            }
        }
    }

    /**
     * Elimina un estudiante de la lista según su identificador.
     * @param id El identificador del estudiante a eliminar.
     */
    public void eliminar(int id) {
        estudiantes.removeIf(e -> e.getId() == id);  // Elimina el estudiante que coincida con el id
    }
}