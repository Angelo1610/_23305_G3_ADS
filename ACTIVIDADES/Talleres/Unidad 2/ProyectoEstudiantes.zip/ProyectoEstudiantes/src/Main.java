package presentacion;

public class Main {
    public static void main(String[] args) {
        //iniciar la interfaz
        EstudianteUI ui = new EstudianteUI();
    }
}