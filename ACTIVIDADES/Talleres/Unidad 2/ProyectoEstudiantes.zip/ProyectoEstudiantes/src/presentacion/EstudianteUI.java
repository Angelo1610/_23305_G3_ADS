package presentacion;

/**
 * Clase que implementa la interfaz de usuario gráfica para gestionar estudiantes.
 * Utiliza Java Swing para crear una ventana con formulario y tabla.
 */
import logica_negocio.EstudianteService;
import datos.model.Estudiante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class EstudianteUI {
    private EstudianteService servicio = new EstudianteService();  // Servicio para manejar la lógica de negocio
    private JFrame frame;                                        // Ventana principal
    private JTextField txtId, txtNombre, txtEdad;                 // Campos de texto para entrada de datos
    private JTable table;                                        // Tabla para mostrar estudiantes
    private DefaultTableModel tableModel;                        // Modelo de la tabla

    /**
     * Constructor de la clase que inicializa la interfaz gráfica.
     */
    public EstudianteUI() {
        frame = new JFrame("Gestión de Estudiantes");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        // Panel de entrada con diseño de cuadrícula
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        inputPanel.add(new JLabel("ID:"));
        txtId = new JTextField(10);  // Campo para el identificador
        inputPanel.add(txtId);
        inputPanel.add(new JLabel("Nombre:"));
        txtNombre = new JTextField(10);  // Campo para el nombre
        inputPanel.add(txtNombre);
        inputPanel.add(new JLabel("Edad:"));
        txtEdad = new JTextField(10);  // Campo para la edad
        inputPanel.add(txtEdad);

        // Creación de botones
        JButton btnAgregar = new JButton("Agregar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnBuscar = new JButton("Buscar");
        JButton btnListar = new JButton("Listar");

        // Configuración de la tabla
        tableModel = new DefaultTableModel(new Object[]{"ID", "Nombre", "Edad"}, 0);  // Encabezados de la tabla
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);  // Panel con desplazamiento para la tabla

        // Panel para los botones
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAgregar);
        buttonPanel.add(btnModificar);
        buttonPanel.add(btnEliminar);
        buttonPanel.add(btnBuscar);
        buttonPanel.add(btnListar);

        // Diseño principal de la ventana
        frame.setLayout(new BorderLayout(10, 10));
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Acciones de los botones
        btnAgregar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText());  // Obtiene el ID desde el campo de texto
                String nombre = txtNombre.getText();         // Obtiene el nombre
                int edad = Integer.parseInt(txtEdad.getText());  // Obtiene la edad
                servicio.agregarEstudiante(id, nombre, edad);  // Agrega el estudiante
                actualizarTabla();  // Actualiza la tabla
                limpiarCampos();    // Limpia los campos
                JOptionPane.showMessageDialog(frame, "Estudiante agregado exitosamente.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese valores numéricos válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnModificar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText());  // Obtiene el ID
                String nombre = txtNombre.getText();         // Obtiene el nombre
                int edad = Integer.parseInt(txtEdad.getText());  // Obtiene la edad
                Estudiante estudianteExistente = servicio.buscarPorId(id);  // Busca el estudiante
                if (estudianteExistente != null) {
                    servicio.modificarEstudiante(id, nombre, edad);  // Modifica el estudiante
                    actualizarTabla();  // Actualiza la tabla
                    limpiarCampos();    // Limpia los campos
                    JOptionPane.showMessageDialog(frame, "Estudiante modificado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Estudiante no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese valores numéricos válidos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnEliminar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText());  // Obtiene el ID
                servicio.eliminarEstudiante(id);  // Elimina el estudiante
                actualizarTabla();  // Actualiza la tabla
                limpiarCampos();    // Limpia los campos
                JOptionPane.showMessageDialog(frame, "Estudiante eliminado exitosamente.");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese un valor numérico válido para el ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnBuscar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(txtId.getText());  // Obtiene el ID
                Estudiante estudiante = servicio.buscarPorId(id);  // Busca el estudiante
                if (estudiante != null) {
                    txtNombre.setText(estudiante.getNombre());  // Muestra el nombre
                    txtEdad.setText(String.valueOf(estudiante.getEdad()));  // Muestra la edad
                } else {
                    JOptionPane.showMessageDialog(frame, "Estudiante no encontrado.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese un valor numérico válido para el ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnListar.addActionListener(e -> actualizarTabla());  // Actualiza la tabla con la lista de estudiantes

        // Configuración final de la ventana
        frame.setLocationRelativeTo(null);  // Centra la ventana
        frame.setVisible(true);             // Hace visible la ventana
    }

    /**
     * Actualiza la tabla con la lista de estudiantes actuales.
     */
    private void actualizarTabla() {
        tableModel.setRowCount(0);  // Limpia las filas existentes
        List<Estudiante> estudiantes = servicio.listarEstudiantes();  // Obtiene la lista de estudiantes
        for (Estudiante e : estudiantes) {
            tableModel.addRow(new Object[]{e.getId(), e.getNombre(), e.getEdad()});  // Añade cada estudiante a la tabla
        }
    }

    /**
     * Limpia los campos de texto de la interfaz.
     */
    private void limpiarCampos() {
        txtId.setText("");      // Limpia el campo de ID
        txtNombre.setText("");  // Limpia el campo de nombre
        txtEdad.setText("");    // Limpia el campo de edad
    }

    /**
     * Método principal que inicia la aplicación gráfica.
     * @param args Argumentos de la línea de comandos (no utilizados).
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(EstudianteUI::new);  // Inicia la interfaz en el hilo de despacho de eventos
    }
}